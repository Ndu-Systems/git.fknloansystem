 $timeout(function () {
        //Get Customers    
   
    }, 2000)